import React from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Stats } from './components/Stats';
import { BottomImage } from './components/BottomImage';

export default function App() {
  return (
    <div className="min-h-screen bg-[#000000] text-white">
      <Header />
      <main className="container mx-auto px-4">
        <Hero />
        <Stats />
        <BottomImage />
      </main>
    </div>
  );
}