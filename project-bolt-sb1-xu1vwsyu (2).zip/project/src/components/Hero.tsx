import React from 'react';
import { ChevronDown } from 'lucide-react';

export function Hero() {
  return (
    <div className="text-center max-w-5xl mx-auto bg-white rounded-[2rem] p-12 mb-8 hover:shadow-2xl transition-shadow duration-300">
      <h2 className="text-4xl md:text-5xl font-extrabold mb-6 leading-tight text-black animate-fadeIn">
        Быстрая, выгодная и безопасная оптимизация Windows
      </h2>
      <p className="text-xl mb-10 text-gray-600 animate-slideUp">
        Избавьтесь от фризов, понизьте задержку и поднимите FPS
      </p>
      <a 
        href="http://t.me/maxioptimization" 
        className="inline-block order-button bg-black text-white text-xl px-16 py-4 rounded-full hover:bg-gray-900 hover:scale-105 transition-all duration-300 font-bold"
      >
        Заказать
      </a>
      <div className="mt-16">
        <ChevronDown className="w-8 h-8 mx-auto animate-bounce text-black" />
      </div>
    </div>
  );
}