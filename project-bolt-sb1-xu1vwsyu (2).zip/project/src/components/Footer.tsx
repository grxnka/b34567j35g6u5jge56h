import React from 'react';

export function Footer() {
  return (
    <footer className="container mx-auto px-4 pb-8">
      <div className="bg-[#1A1A1A] rounded-[2rem] p-8">
        <div className="flex justify-between items-center">
          <div className="flex gap-20">
            {/* Left Links */}
            <div className="flex flex-col gap-6">
              <a 
                href="http://t.me/maxioptimization" 
                className="text-white hover:text-gray-300 transition-colors text-lg"
              >
                Заказать
              </a>
              <a 
                href="https://t.me/maxi_optimization/57" 
                className="text-white hover:text-gray-300 transition-colors text-lg"
              >
                О программе
              </a>
              <a 
                href="http://t.me/maxioptimization" 
                className="text-white hover:text-gray-300 transition-colors text-lg"
              >
                Контакты
              </a>
            </div>

            {/* Divider */}
            <div className="w-[2px] h-32 bg-gray-700 rounded-full"></div>

            {/* Right Links */}
            <div className="flex flex-col gap-6">
              <a 
                href="https://t.me/maxi_optimization" 
                className="text-white hover:text-gray-300 transition-colors text-lg"
              >
                Telegram
              </a>
              <a 
                href="https://discord.gg/GmEw5pheQE" 
                className="text-white hover:text-gray-300 transition-colors text-lg"
              >
                Discord
              </a>
              <a 
                href="https://www.tiktok.com/@grxnka" 
                className="text-white hover:text-gray-300 transition-colors text-lg"
              >
                TikTok
              </a>
            </div>
          </div>

          {/* Image */}
          <img 
            src="https://i.ibb.co/0qCYLTL/Picsart-24-12-08-14-52-51-153.jpg" 
            alt="MAXI optimization"
            className="h-40 object-contain"
          />
        </div>
      </div>
    </footer>
  );
}