import React from 'react';

export function BottomImage() {
  return (
    <div className="relative max-w-5xl mx-auto mb-8">
      <img 
        src="https://i.ibb.co/0qCYLTL/Picsart-24-12-08-14-52-51-153.jpg" 
        alt="MAXI optimization"
        className="w-full h-auto rounded-[2rem] hover:scale-[1.02] transition-transform duration-300"
      />
      <div className="absolute top-24 left-[46%] flex flex-col gap-4">
        <a 
          href="http://t.me/maxioptimization" 
          className="text-white hover:text-gray-300 hover:scale-110 transition-all duration-300 text-lg"
        >
          Заказать
        </a>
        <a 
          href="https://t.me/maxi_optimization/57" 
          className="text-white hover:text-gray-300 hover:scale-110 transition-all duration-300 text-lg"
        >
          О программе
        </a>
        <a 
          href="http://t.me/maxioptimization" 
          className="text-white hover:text-gray-300 hover:scale-110 transition-all duration-300 text-lg"
        >
          Контакты
        </a>
      </div>
      <div className="absolute top-24 right-28 flex flex-col gap-4">
        <a 
          href="https://t.me/maxi_optimization" 
          className="text-white hover:text-gray-300 hover:scale-110 transition-all duration-300 text-lg"
        >
          Telegram
        </a>
        <a 
          href="https://discord.gg/GmEw5pheQE" 
          className="text-white hover:text-gray-300 hover:scale-110 transition-all duration-300 text-lg"
        >
          Discord
        </a>
        <a 
          href="https://www.tiktok.com/@grxnka" 
          className="text-white hover:text-gray-300 hover:scale-110 transition-all duration-300 text-lg"
        >
          TikTok
        </a>
      </div>
      <img 
        src="https://i.ibb.co/QdM90xs/Picsart-24-12-10-15-50-54-595.jpg" 
        alt="Additional MAXI optimization"
        className="w-full h-auto rounded-[2rem] mt-8 hover:scale-[1.02] transition-transform duration-300"
      />
    </div>
  );
}