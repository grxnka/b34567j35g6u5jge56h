import React from 'react';

export function Stats() {
  return (
    <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto mb-8">
      <div className="bg-white rounded-[2rem] p-4 text-black flex items-center justify-center">
        <img 
          src="https://i.ibb.co/74HzKpt/Picsart-24-12-08-14-31-38-951.jpg" 
          alt="Client Statistics"
          className="w-full h-full object-contain"
        />
      </div>
      
      <div className="bg-white rounded-[2rem] p-4 text-black flex items-center justify-center">
        <img 
          src="https://i.ibb.co/HhvxvvQ/image.png" 
          alt="Performance Stats"
          className="w-full h-full object-contain"
        />
      </div>
    </div>
  );
}