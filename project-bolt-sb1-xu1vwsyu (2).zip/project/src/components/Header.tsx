import React from 'react';
import { HelpCircle } from 'lucide-react';

export function Header() {
  return (
    <header className="w-full flex flex-col items-center p-6 bg-black">
      <div className="w-full flex justify-between items-center mb-4">
        <div className="w-1/3"></div>
        <div className="w-1/3 flex justify-center">
          <a href="https://jazzy-marshmallow-be28bb.netlify.app/">
            <img 
              src="https://i.ibb.co/1d50m8m/image-1.png" 
              alt="MAXI OPTIMIZATION"
              className="w-[350px] h-auto object-contain transform scale-150 hover:scale-[1.6] transition-transform duration-300 cursor-pointer"
            />
          </a>
        </div>
        <div className="w-1/3 flex justify-end">
          <a 
            href="https://precious-dasik-4c6aca.netlify.app/" 
            className="text-lg font-medium flex items-center gap-2 text-white hover:text-gray-300 hover:scale-110 transition-all duration-300"
          >
            FAQ
            <HelpCircle className="w-5 h-5 animate-pulse" />
          </a>
        </div>
      </div>
    </header>
  );
}