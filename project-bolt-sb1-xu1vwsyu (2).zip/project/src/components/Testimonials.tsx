import React from 'react';

export function Testimonials() {
  return (
    <div className="container mx-auto px-4 mb-8">
      <div className="bg-[#1A1A1A] rounded-[2rem] p-8 flex justify-between">
        {/* Reviews Section */}
        <div className="w-1/2">
          <div className="space-y-6">
            {/* Review 1 */}
            <div className="flex items-start gap-4">
              <img
                src="https://i.ibb.co/74HzKpt/Picsart-24-12-08-14-31-38-951.jpg"
                alt="User"
                className="w-12 h-12 rounded-full"
              />
              <div>
                <h3 className="text-white font-semibold">Savjndn.21</h3>
                <p className="text-gray-300 text-sm">
                  Все сделали отлично, быстро, задержка стала намного меньше, (фортнайт) было максимум 340фпс, стало 440, thx so much, Советую!
                </p>
              </div>
            </div>

            {/* Review 2 */}
            <div className="flex items-start gap-4">
              <img
                src="https://i.ibb.co/74HzKpt/Picsart-24-12-08-14-31-38-951.jpg"
                alt="User"
                className="w-12 h-12 rounded-full"
              />
              <div>
                <h3 className="text-white font-semibold">ZZZ</h3>
                <p className="text-gray-300 text-sm">
                  Оптимизация помогла раньше были просадки фпс сейчас все стабильно делали за 5 минут я офигел спасибо
                </p>
              </div>
            </div>

            {/* Review 3 */}
            <div className="flex items-start gap-4">
              <img
                src="https://i.ibb.co/74HzKpt/Picsart-24-12-08-14-31-38-951.jpg"
                alt="User"
                className="w-12 h-12 rounded-full"
              />
              <div>
                <h3 className="text-white font-semibold">m...</h3>
                <p className="text-gray-300 text-sm">
                  Все четко быстро, плавность стабильность все есть, советую (+100 фпс, -10 пинг)
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Links Section */}
        <div className="w-1/2 flex justify-end items-center">
          <div className="flex gap-20">
            {/* Left Links */}
            <div className="flex flex-col gap-4">
              <a 
                href="http://t.me/maxioptimization"
                className="text-white hover:text-gray-300 transition-colors"
              >
                Заказать
              </a>
              <a 
                href="https://t.me/maxi_optimization/57"
                className="text-white hover:text-gray-300 transition-colors"
              >
                О программе
              </a>
              <a 
                href="http://t.me/maxioptimization"
                className="text-white hover:text-gray-300 transition-colors"
              >
                Контакты
              </a>
            </div>

            {/* Divider */}
            <div className="w-[2px] h-32 bg-gray-700 rounded-full"></div>

            {/* Right Links */}
            <div className="flex flex-col gap-4">
              <a 
                href="https://t.me/maxi_optimization"
                className="text-white hover:text-gray-300 transition-colors"
              >
                Telegram
              </a>
              <a 
                href="https://discord.gg/GmEw5pheQE"
                className="text-white hover:text-gray-300 transition-colors"
              >
                Discord
              </a>
              <a 
                href="https://www.tiktok.com/@grxnka"
                className="text-white hover:text-gray-300 transition-colors"
              >
                TikTok
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}